# Plant-Care
Image recognition software specialized in detecting symptoms of viruses and parasites in plants.<br />
DataSet used: PlantVillage<br />
Language: Python<br />
Library: Tensorflow<br />
Article reviews are used as a starting point refrence, they can be found in the "Research Material" Branch<br />
All in one model not included: file size exceeds github 100mb capacity
